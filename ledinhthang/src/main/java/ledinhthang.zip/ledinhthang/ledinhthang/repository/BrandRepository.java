package  ledinhthang.ledinhthang.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ledinhthang.ledinhthang.entity.Brand;

public interface BrandRepository extends JpaRepository<Brand, Integer> {
}
