package  ledinhthang.ledinhthang.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ledinhthang.ledinhthang.entity.Banner;

public interface BannerRepository extends JpaRepository<Banner, Integer> {
}